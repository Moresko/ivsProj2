Prostredi
---------

Ubuntu 64bit

Autori
------

Nazev tymu
- xkasem02 Jakub Kasem 
- xmores02 Martin Mores 
- xbotlo01 Filip Botlo
- xkozak20 Katarína Kozáková

Licence
-------

Tento program je poskytovan pod GNU GENERAL PUBLIC LICENSE Version 2.
